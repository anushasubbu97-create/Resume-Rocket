const $ = id => document.getElementById(id);
const STORAGE_KEY = "resumerocket-draft-v2";
const formFields = ["name","title","email","phone","location","links","summary","skills","jobDescription"];
const lists = {education: $("educationList"), experience: $("experienceList"), project: $("projectList"), certification: $("certificationList")};
let saveTimer;

const configs = {
  education: [["degree","Degree / course"],["school","College / university"],["year","Year / duration"],["details","Grade / details"]],
  experience: [["role","Job title"],["company","Company"],["period","Dates"],["details","Responsibilities / achievements"]],
  project: [["projectName","Project name"],["tech","Technologies"],["details","Project description"]],
  certification: [["certName","Certification name"],["issuer","Issuing organization"],["certYear","Year / credential"]]
};

function addEntry(type, values = {}) {
  const entry = document.createElement("div");
  entry.className = "entry"; entry.dataset.type = type;
  const head = document.createElement("div"); head.className = "entry-head";
  const number = document.createElement("span"); number.className = "entry-number"; number.textContent = `${type[0].toUpperCase()+type.slice(1)} entry`;
  const remove = document.createElement("button"); remove.type = "button"; remove.className = "remove-btn"; remove.textContent = "Remove";
  remove.setAttribute("aria-label", `Remove ${type} entry`);
  remove.addEventListener("click", () => { entry.remove(); updatePreview(); scheduleAutosave(); });
  head.append(number, remove);
  const fields = document.createElement("div"); fields.className = "fields two";
  configs[type].forEach(([key, label]) => {
    const wrap = document.createElement("label"); wrap.textContent = label;
    const input = key === "details" ? document.createElement("textarea") : document.createElement("input");
    if (key === "details") input.rows = 2;
    input.dataset.key = key; input.placeholder = label; input.value = values[key] || "";
    input.addEventListener("input", () => { updatePreview(); scheduleAutosave(); });
    wrap.appendChild(input); fields.appendChild(wrap);
  });
  entry.append(head, fields); lists[type].appendChild(entry); updatePreview();
}
function getEntries(type) {
  return [...lists[type].querySelectorAll(".entry")].map(entry => {
    const data = {}; entry.querySelectorAll("[data-key]").forEach(input => data[input.dataset.key] = input.value.trim()); return data;
  }).filter(item => Object.values(item).some(Boolean));
}
function esc(value) { return String(value || "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
function itemHTML(title, meta, details) {
  if (![title,meta,details].some(Boolean)) return "";
  return `<div class="resume-item">${title ? `<strong>${esc(title)}</strong>` : ""}${meta ? `<p class="meta">${esc(meta)}</p>` : ""}${details ? `<p class="description">${esc(details)}</p>` : ""}</div>`;
}
function renderList(type, target, emptyText, titleFn, metaFn, detailFn) {
  const items = getEntries(type);
  $(target).innerHTML = items.length ? items.map(x => itemHTML(titleFn(x),metaFn(x),detailFn(x))).join("") : `<p class="placeholder">${emptyText}</p>`;
  const section = $(target).closest(".resume-section"); if (section) section.hidden = !items.length;
}
function updatePreview() {
  const val = id => $(id).value.trim();
  $("pName").textContent = val("name") || "Your Name";
  $("pTitle").textContent = val("title") || "Your Professional Title";
  $("pContact").textContent = [val("email"),val("phone"),val("location"),val("links")].filter(Boolean).join("  ·  ") || "Email · Phone · Location · LinkedIn";
  $("pSummary").textContent = val("summary") || "Your professional summary will appear here.";
  $("pSummary").classList.toggle("placeholder", !val("summary"));
  $("pSkills").textContent = val("skills") || "Your skills will appear here.";
  $("pSkills").classList.toggle("placeholder", !val("skills"));
  $("summarySection").hidden = !val("summary"); $("skillsSection").hidden = !val("skills");
  renderList("experience","pExperience","Your work experience will appear here.",x=>x.role,x=>[x.company,x.period].filter(Boolean).join(" | "),x=>x.details);
  renderList("education","pEducation","Your education will appear here.",x=>x.degree,x=>[x.school,x.year].filter(Boolean).join(" | "),x=>x.details);
  renderList("project","pProjects","Your projects will appear here.",x=>x.projectName,x=>x.tech,x=>x.details);
  renderList("certification","pCertifications","Your certifications will appear here.",x=>x.certName,x=>[x.issuer,x.certYear].filter(Boolean).join(" | "),()=>"");
  $("resumePreview").className = `resume ${$("template").value}`;
  $("summaryCount").textContent = val("summary").length;
  updateCompletion(); calculateScore(false);
}
function updateCompletion() {
  const val = id => $(id).value.trim();
  const completed = [!!val("name"),!!val("title"),!!val("email"),!!val("phone"),!!val("summary"),getEntries("education").length>0,getEntries("experience").length>0,getEntries("project").length>0,!!val("skills")];
  const pct = Math.round(completed.filter(Boolean).length/completed.length*100);
  $("completionText").textContent = `${pct}% complete`; $("completionBar").style.width = `${pct}%`;
  $("completionHint").textContent = pct===100 ? "Great start — review your content and export when ready." : "Complete your key details and sections to build a stronger resume.";
}
function calculateScore(showMessage = true) {
  const val = id => $(id).value.trim();
  const experience = getEntries("experience"), education = getEntries("education"), projects = getEntries("project"), certs = getEntries("certification");
  const skills = val("skills").split(/[,\n]/).map(s=>s.trim()).filter(Boolean);
  const checks = [
    [!!val("name") && !!val("email") && !!val("phone"),15], [!!val("title"),8], [!!val("summary") && val("summary").length>=50,12],
    [education.length>0,12], [experience.length>0,15], [projects.length>0,10], [skills.length>=3,12],
    [!!val("location") && !!val("links"),5],
    [experience.some(x=>/\d+%|\d+\+|\$\s?\d+|\b(increased|reduced|saved|managed|led|delivered)\b/i.test(x.details)),6],
    [certs.length>0,5]
  ];
  const score = checks.reduce((sum,[ok,points])=>sum+(ok?points:0),0);
  $("score").textContent = score; $("scoreBar").style.width = `${score}%`;
  $("scoreLabel").textContent = score>=85 ? "Strong foundation" : score>=65 ? "Good progress" : score>=40 ? "Room to improve" : "Add your details";
  if(showMessage) toast(`Resume checkup: ${score}/100`);
  return score;
}
function toast(message) { const t=$("toast"); t.textContent=message; t.classList.add("show"); clearTimeout(toast.timer); toast.timer=setTimeout(()=>t.classList.remove("show"),2400); }
function collectData() {
  const data={}; formFields.forEach(id=>data[id]=$(id).value); data.template=$("template").value;
  Object.keys(lists).forEach(type=>data[type]=getEntries(type)); return data;
}
function saveDraft(showToast=true) {
  try { localStorage.setItem(STORAGE_KEY,JSON.stringify(collectData())); $("saveState").innerHTML='<span class="status-dot"></span> Saved on this device'; if(showToast)toast("Draft saved on this device."); }
  catch(error) { console.warn("Draft could not be saved",error); if(showToast)toast("Could not save. Check browser storage settings."); }
}
function scheduleAutosave() { $("saveState").innerHTML='<span class="status-dot" style="background:#e3a43b"></span> Unsaved changes'; clearTimeout(saveTimer); saveTimer=setTimeout(()=>saveDraft(false),700); }
function loadDraft() {
  try {
    const raw=localStorage.getItem(STORAGE_KEY); if(!raw)return;
    const data=JSON.parse(raw); formFields.forEach(id=>{if(typeof data[id]==="string")$(id).value=data[id];});
    $("template").value=data.template||"modern";
    Object.keys(lists).forEach(type=>{lists[type].innerHTML="";(Array.isArray(data[type])?data[type]:[]).forEach(item=>addEntry(type,item));});
    $("saveState").innerHTML='<span class="status-dot"></span> Draft restored';
  } catch(error) { console.warn("Saved draft could not be restored",error); }
}
function tokenize(text) { return (text.toLowerCase().match(/[a-z][a-z+#.]{1,}/g)||[]).map(w=>w.replace(/[.,]+$/,"")); }
function matchKeywords() {
  const job=$("jobDescription").value.trim(); const output=$("keywordResults");
  if(!job) { output.innerHTML='<p class="keyword-summary">Paste a job description first to see matching terms.</p>'; return; }
  const resume=[$("title").value,$("summary").value,$("skills").value,...Object.keys(lists).flatMap(type=>getEntries(type).flatMap(x=>Object.values(x)))].join(" ").toLowerCase();
  const stop=new Set("the and for with you our are will that this from have has your job work team years year who all any able about into their they use using experience skills role must should can candidate ability strong including preferred required knowledge looking seeking responsible responsibilities qualifications such plus across ensure support develop build".split(" "));
  const words=tokenize(job); const counts=new Map(); words.forEach(w=>{if(w.length>2&&!stop.has(w))counts.set(w,(counts.get(w)||0)+1);});
  const keywords=[...counts.keys()].sort((a,b)=>counts.get(b)-counts.get(a)).slice(0,40);
  const found=keywords.filter(w=>resume.includes(w)); const missing=keywords.filter(w=>!resume.includes(w));
  output.innerHTML=`<p class="keyword-summary"><strong>${found.length}</strong> matching terms · <strong>${missing.length}</strong> terms to review</p><div class="tag-list">${found.map(w=>`<span class="tag">${esc(w)} ✓</span>`).join("")}${missing.map(w=>`<span class="tag missing">${esc(w)} +</span>`).join("")}</div><p class="keyword-legend">Green = found in your resume · Amber = consider adding only if it accurately reflects your experience.</p>`;
}
function clearResume() {
  $("resumeForm").reset(); Object.values(lists).forEach(list=>list.innerHTML="");
  Object.keys(lists).forEach(type=>addEntry(type)); $("keywordResults").innerHTML="";
  localStorage.removeItem(STORAGE_KEY); $("template").value="modern"; updatePreview();
  $("saveState").innerHTML='<span class="status-dot"></span> Changes are local'; toast("Resume form cleared.");
}
function downloadPDF() {
  const element=$("resumePreview"); const options={margin:0,filename:"ResumeRocket-Resume.pdf",image:{type:"jpeg",quality:.98},html2canvas:{scale:2,useCORS:true,backgroundColor:"#ffffff"},jsPDF:{unit:"mm",format:"a4",orientation:"portrait"},pagebreak:{mode:["css","legacy"]}};
  if(window.html2pdf) { window.html2pdf().set(options).from(element).save().catch(()=>{toast("PDF export failed. Opening print dialog.");window.print();}); }
  else { toast("PDF library unavailable. Use Print → Save as PDF."); window.print(); }
}
formFields.forEach(id=>$(id).addEventListener("input",()=>{updatePreview();scheduleAutosave();}));
$("template").addEventListener("change",()=>{updatePreview();scheduleAutosave();});
$("addEducation").addEventListener("click",()=>addEntry("education"));
$("addExperience").addEventListener("click",()=>addEntry("experience"));
$("addProject").addEventListener("click",()=>addEntry("project"));
$("addCertification").addEventListener("click",()=>addEntry("certification"));
$("saveBtn").addEventListener("click",()=>saveDraft(true));
$("evaluateBtn").addEventListener("click",()=>calculateScore(true));
$("matchBtn").addEventListener("click",matchKeywords);
$("downloadBtn").addEventListener("click",downloadPDF);
$("clearBtn").addEventListener("click",()=>$("clearDialog").showModal());
$("confirmClear").addEventListener("click",event=>{event.preventDefault();$("clearDialog").close();clearResume();});
loadDraft();
Object.keys(lists).forEach(type=>{if(!getEntries(type).length)addEntry(type);});
updatePreview();
